 #include <LiquidCrystal.h>

// LCD pin connections: RS, E, D4, D5, D6, D7
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const int sensorPin = A0;     // Analog Temperature Sensor output
const int buzzer = 8;         // Passive buzzer pin
const int greenLED = 9;       // Safe temperature
const int yellowLED = 10;     // Warning temperature
const int redLED = 7;         // Overheat temperature

float temperature;

void setup() {
  lcd.begin(16, 2);
  lcd.print("Boiler Control");
  delay(1500);
  lcd.clear();

  pinMode(buzzer, OUTPUT);
  pinMode(greenLED, OUTPUT);
  pinMode(yellowLED, OUTPUT);
  pinMode(redLED, OUTPUT);

  Serial.begin(9600);
}

void loop() {
  int sensorValue = analogRead(sensorPin);

  // Convert analog value (0–1023) to temperature (-40°C to 125°C)
  temperature = map(sensorValue, 0, 1023, -40, 125);

  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(temperature);
  lcd.print((char)223); // degree symbol
  lcd.print("C   ");

  Serial.print("Temperature: ");
  Serial.println(temperature);

  // LED + Buzzer Logic
  if (temperature < 38) {
    // Normal range
    digitalWrite(greenLED, HIGH);
    digitalWrite(yellowLED, LOW);
    digitalWrite(redLED, LOW);
    noTone(buzzer);
    lcd.setCursor(0, 1);
    lcd.print("Status: Normal   ");
  } 
  else if (temperature >= 38 && temperature < 68) {
    // Warning range
    digitalWrite(greenLED, LOW);
    digitalWrite(yellowLED, HIGH);
    digitalWrite(redLED, LOW);
    noTone(buzzer);
    lcd.setCursor(0, 1);
    lcd.print("Status: Warning  ");
  } 
  else {
    // Overheat range
    digitalWrite(greenLED, LOW);
    digitalWrite(yellowLED, LOW);
    digitalWrite(redLED, HIGH);
    tone(buzzer, 1000);  // 1 kHz tone for overheat alert
    lcd.setCursor(0, 1);
    lcd.print("Status: OVERHEAT!");
  }

  delay(1000);
}